# Views Exposed Fields Filter

This is a contributed module to expose fields to visitors for
the keywords to search in.

The flow is going to be:

User will enter a keyword to search and then select the field
from drop down to search in.

Example: search "shabir"  and select first name from field list
will search "shabir" in first name fields.
